package hw5;

public class HuffmanNode implements Comparable<HuffmanNode> {
    private String letter; //String to store the character
    private double frequency; //Frequency of the character
    private HuffmanNode left; //Child
    private HuffmanNode right; 

    // Constructor for leaf node
    public HuffmanNode(String letter, double frequency) {
        this.letter = letter;
        this.frequency = frequency;
        this.left = null;
        this.right = null;
    }

    // internal node
    public HuffmanNode(HuffmanNode left, HuffmanNode right) {
        this.letter = left.letter + right.letter; // concatenation of letters
        this.frequency = left.frequency + right.frequency; // sum of frequencies
        this.left = left;
        this.right = right;
    }

    // Compare based on frequency
    @Override
    public int compareTo(HuffmanNode huff) {
        return Double.compare(this.frequency, huff.frequency);
    }

    // toString method
    @Override
    public String toString() {
        return "<" + letter + ", " + frequency + ">";
    }

    // Getters and maybe setters if I need it
    public String getLetter() {
        return letter;
    }

    public double getFrequency() {
        return frequency;
    }

    public HuffmanNode getLeft() {
        return left;
    }

    public HuffmanNode getRight() {
        return right;
    }
}