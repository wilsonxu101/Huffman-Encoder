package hw5;

public class HuffmanTree {
    private HuffmanNode root;

    //constructor
    public HuffmanTree(HuffmanNode huff) {
        this.root = huff;
    }

    // Method to print the Huffman encoding legend
    public void printLegend() {
        printLegend(root, "");
    }

    
    // Need Recursive helper method for printLegend
    private void printLegend(HuffmanNode node, String code) {
        if (node != null) {
            if (node.getLetter().length() > 1) { // Not a leaf node
                printLegend(node.getLeft(), code + "0");
                printLegend(node.getRight(), code + "1");
            } else { // Leaf node
                System.out.println(node.getLetter() + "=" + code);
            }
        }
    }

    // Convert a string legend into a binary heap of Huffman nodes
    public static BinaryHeap<HuffmanNode> legendToHeap(String legend) {
        BinaryHeap<HuffmanNode> heap = new BinaryHeap<>();
        String[] parts = legend.split(" ");
        for (int i = 0; i < parts.length; i += 2) {
            String element = String.valueOf(parts[i].charAt(0)); // Convert char to String
            double frequency = Double.parseDouble(parts[i + 1]); // Convert int to double
            heap.insert(new HuffmanNode(element, frequency));
        }
        return heap;
    }

    // Need to run algorithm and create a HuffmanTree from a binary heap
    public static HuffmanTree createFromHeap(BinaryHeap<HuffmanNode> heap) {
        while (heap.getSize() > 1) { //getSize use
            HuffmanNode left = heap.deleteMin();
            HuffmanNode right = heap.deleteMin();
            HuffmanNode parent = new HuffmanNode(left, right); // in case takes two children
            heap.insert(parent);
        }
        return new HuffmanTree(heap.deleteMin());
    }

    // Main method to test my program
    public static void main(String[] args) {
    	// In Pdf instruction, it said it's ok to hardcode this string
        String legend = "A 20 E 24 G 3 H 4 I 17 L 6 N 5 O 10 S 8 V 1 W 2"; 
        BinaryHeap<HuffmanNode> heap = legendToHeap(legend);

        //Printing the heap,if printHeap() method is implemented in BinaryHeap
        heap.printHeap();

        //Creating Huffman Tree from heap and print the legend
        HuffmanTree huffmanTree = createFromHeap(heap);
        huffmanTree.printLegend();
    }
}