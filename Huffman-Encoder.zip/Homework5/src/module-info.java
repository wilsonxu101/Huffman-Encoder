module Homework5 {
}